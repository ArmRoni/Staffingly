jQuery(window).scroll(function () {
  if (jQuery(this).scrollTop() > 50) {
    jQuery('.header').addClass('header-position');
  } else {
    jQuery('.header').removeClass('header-position');
  }
});

jQuery(function () {
  jQuery('#menu-nav').slicknav({
    label: '',
    allowParentLinks: false,
    openedSymbol: "",
    closedSymbol: "",
    prependTo: '#menu_holder'
  });
});
(jQuery);


jQuery(".nav-toggler").click(function () {
  jQuery(this).toggleClass("active");
  jQuery("#menu_holder").toggleClass("mobile-menu-open");
  jQuery(".header").toggleClass("header-bg");
  jQuery("body").toggleClass("overflow-hidden");
});

jQuery(".menu-backdrop").click(function () {
  jQuery(".nav-toggler").removeClass("active");
  jQuery("#menu_holder").removeClass("mobile-menu-open");
  jQuery(".header").removeClass("header-bg");
  jQuery("body").removeClass("overflow-hidden");
});

jQuery('.leather-brand-slider').owlCarousel({
  loop: true,
  responsiveClass: true,
  autoplay: true,
  nav: false,
  dots: true,
  autoplayTimeout: 5000,
  responsive: {
    0: {
      items: 1,
      dotsEach: 3,
    },
    500: {
      items: 2,
    },
    991: {
      items: 4,
    },
    1366: {
      items: 4,
    },
    1700: {
      items: 5,
    }
  }
});


//======= experience-slider===========

jQuery(document).ready(function () {
  var slider = jQuery('.experience-slider').owlCarousel({
    loop: true,
    items: 1,
    autoplay: true,
    margin:3,
    nav: false,
    dots: true,
    autoplayTimeout: 5000,
  });

  jQuery('.nav-arrow-left').click(function () {
      slider.trigger('prev.owl.carousel');
    });
    jQuery('.nav-arrow-right').click(function () {
      slider.trigger('next.owl.carousel');
  });

  // Function to update navigation arrow images
  function updateNavImages(currentIndex) {
    var items = jQuery('.experience-slider .voices-experience-item'); // All slider items
    var totalItems = items.length;

    // Calculate indexes for previous and next items
    var prevIndex = (currentIndex - 1 + totalItems) % totalItems; // Previous index
    var nextIndex = (currentIndex + 1) % totalItems; // Next index

    // Get image sources for previous and next items
    var prevImage = items.eq(prevIndex).find('.voices-experience-photo img').attr('src');
    var nextImage = items.eq(nextIndex).find('.voices-experience-photo img').attr('src');

    // Update the navigation arrow images
    jQuery('.nav-arrow-left img').attr('src', prevImage);
    jQuery('.nav-arrow-right img').attr('src', nextImage);
  }

  // Attach the updateNavImages function to the slider change event
  slider.on('changed.owl.carousel', function (event) {
    var currentIndex = event.item.index;
    updateNavImages(currentIndex);
  });

    // Manually trigger the function after slider initialization to ensure images are loaded
    updateNavImages(0); // Set initial images based on the first slide
});




jQuery('.blog-slider').owlCarousel({
  loop: true,
  responsiveClass: true,
  autoplay: true,
  nav: true,
  margin: 20,
  dots: true,
  autoplayTimeout: 5000,
  navText: [
    '<i class="fa-solid fa-chevron-left"></i>',
    '<i class="fa-solid fa-chevron-right"></i>'
  ],
  responsive: {
    0: {
      items: 1,
      dotsEach: 3,
    },
    600: {
      items: 2,
    },
    991: {
      items: 3,
      margin: 20,
    },
    1340: {
      items: 4,
      margin: 20,
    },
    1500: {
      items: 4,
      margin: 30,
    },
    1700: {
      items: 4,
      margin: 48
    }
  }
});

jQuery('.members-list-slider').owlCarousel({
  loop: true,
  responsiveClass: true,
  autoplay: true,
  nav: true,
  margin: 20,
  dots: true,
  autoplayTimeout: 5000,
  navText: [
    '<i class="fa-solid fa-chevron-left"></i>',
    '<i class="fa-solid fa-chevron-right"></i>'
  ],
  responsive: {
    0: {
      items: 1,
      dotsEach: 3,
    },
    600: {
      items: 2,
    }
  }
});

jQuery('.banner-slider').owlCarousel({
  loop: true,
  responsiveClass: true,
  autoplay: true,
  nav: false,
  margin:3,
  dots: false,
  items: 1,
  autoplayTimeout: 5000,
  animateOut: 'fadeOut'
});




// ==========accordion js=============

const accoHaders = document.querySelectorAll('.accordion-header');
accoHaders.forEach(accoHeader => {
  accoHeader.addEventListener("click", () => {
    const item = accoHeader.parentElement;
    item.classList.toggle('active');
  })
})



// ========thumbnail sider js=========

jQuery(document).ready(function () {
  jQuery(".product-content-wrap").each(function () {
    var $this = jQuery(this); // Scope the current .key-attributes-area
    var sync1 = $this.find(".sync1");
    var sync2 = $this.find(".sync2");

    // Retrieve slidesPerPage from data attribute, with a default fallback
    var slidesPerPage = parseInt($this.data("slides-per-page")) || 4; 
    var syncedSecondary = true;

    sync1.owlCarousel({
      items: 1,
      margin: 5,
      slideSpeed: 2000,
      autoHeight: true,
      nav: true,
      animateOut: "fadeOut",
      autoplay: true,
      dots: false,
      loop: false,
      responsiveRefreshRate: 200,
      navText: [
        '<i class="fa-solid fa-chevron-left"></i>',
        '<i class="fa-solid fa-chevron-right"></i>',
      ],
    }).on("changed.owl.carousel", function (event) {
      syncPosition(event);
      toggleNavVisibility(event);
    });

    sync2
      .on("initialized.owl.carousel", function () {
        sync2.find(".owl-item").eq(0).addClass("current");
      })
      .owlCarousel({
        items: slidesPerPage,
        margin: 5,
        dots: false,
        nav: false,
        smartSpeed: 200,
        slideSpeed: 500,
        slideBy: slidesPerPage,
        responsiveRefreshRate: 100,
        responsive: {
          991: {
            margin:10,
          }
        }
      }).on("changed.owl.carousel", syncPosition2);

    function syncPosition(event) {
      var current = event.item.index;

      sync2
        .find(".owl-item")
        .removeClass("current")
        .eq(current)
        .addClass("current");

      var onscreen = sync2.find(".owl-item.active").length - 1;
      var start = sync2.find(".owl-item.active").first().index();
      var end = sync2.find(".owl-item.active").last().index();

      if (current > end) {
        sync2.data("owl.carousel").to(current, 100, true);
      }
      if (current < start) {
        sync2.data("owl.carousel").to(current - onscreen, 100, true);
      }
    }

    function syncPosition2(event) {
      if (syncedSecondary) {
        var number = event.item.index;
        sync1.data("owl.carousel").to(number, 100, true);
      }
    }

    function toggleNavVisibility(event) {
      var count = event.item.count;
      var currentIndex = event.item.index;

      if (currentIndex === 0) {
        $this.find(".owl-nav .fa-chevron-left").hide();
      } else {
        $this.find(".owl-nav .fa-chevron-left").show();
      }
      if (currentIndex === count - 1) {
        $this.find(".owl-nav .fa-chevron-right").hide();
      } else {
        $this.find(".owl-nav .fa-chevron-right").show();
      }
    }

    sync2.on("click", ".owl-item", function (e) {
      e.preventDefault();
      var number = jQuery(this).index();
      sync1.data("owl.carousel").to(number, 300, true);
    });

    toggleNavVisibility({ item: { count: sync1.find(".owl-item").length, index: 0 } });
  });
});



// ========thumbnail new start sider js=========
if (typeof MasterSlider !== 'undefined') {
  const sliderIds = Array.from(document.querySelectorAll('.master-slider')).map(slider => slider.id);
  sliderIds.forEach(function(sliderId) {
      var masterslider = new MasterSlider();

      // Slider Controls
      masterslider.control('arrows', { 
          autohide: false, 
          overVideo: true 
      });

      masterslider.control('thumblist', {
          autohide: false,
          overVideo: true,
          dir: 'h',
          align: 'bottom',
          width: 152,
          space: 12,             
          height: 152
      });

      // Slider Setup
      masterslider.setup(sliderId, {
          width: 770,
          height: 500,
          autoHeight: true,
          space: 0,
          start: 1,
          grabCursor: true,
          swipe: true,
          autoplay: true,
          loop: true,
          preload: 2,
          fillMode: "fill",
          view: "basic",
          speed: 20
      });
  });
} 


//======== botto to top scroll======

jQuery(document).ready(function(){
  jQuery("#scrollTopButton").click(function(){
    jQuery("html, body").animate({scrollTop: 0}, 800);
  });
  // ========git quote bnnar btn js =======
  jQuery('.git-quote-btn').on('click',function(){
    jQuery('.get-quote-form-warp').addClass("active");
  })
  jQuery('.close-btn').on('click',function(){
    jQuery('.get-quote-form-warp').removeClass("active");
  });
  jQuery('.get-quote-form-warp').on("click",function(e){
    if(jQuery(e.target).closest('.contant-us-form').length === 0) {
      jQuery('.get-quote-form-warp').removeClass("active");
    }
  })
});

// ========catagory list scrolling js =======
jQuery(document).ready(function () {
  jQuery('.category-list-content ul li a').on('click', function (event) {
      event.preventDefault();
      var target = jQuery(jQuery(this).attr('href'));
      jQuery('html, body').animate({
          scrollTop: target.offset().top - 50
      }, 1000);
  });
  jQuery('.phone-number input[type="tel"]').on('focus', function() {
    var inputValue = jQuery(this).val();
    if (!inputValue.includes('+')) {
        jQuery(this).val('+' + inputValue);
    }
  });
  jQuery('.phone-number input[type="tel"]').on('keypress', function() {
    var inputValue = jQuery(this).val();
    if (!inputValue.includes('+')) {
        jQuery(this).val('+' + inputValue);
    }
  });
});





// ================Chart js ==================

const ctx = document.getElementById('myChart').getContext('2d');  
const myChart = new Chart(ctx, {  
    type: 'line', // Specify line chart type  
    data: {  
        labels: ['2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024'], // X-axis labels  
        datasets: [  
            {  
                label: 'Employees [Number]', // First line dataset  
                data: [200, 300, 500, 600, 700, 800, 600, 700, 1000, 400, 400, 200], // Data points  
                borderColor: '#15294F', // Blue color for line  
                backgroundColor: 'rgba(0, 0, 255, 0)', // No fill color  
                fill: false, // No fill  
                tension: 0.1, // Slight curve  
                pointRadius: 5, // Size of point markers  
                pointBackgroundColor: '#15294F', // Point color  
            },  
            {  
                label: 'Revenue [$ Millions]', // Second line dataset  
                data: [100, 150, 200, 250, 400, 500, 700, 650, 850, 900, 950, 1000], // Data points  
                borderColor: '#FFBD4C', // Orange color for line  
                backgroundColor: 'rgba(255, 165, 0, 0)', // No fill color  
                fill: false, // No fill  
                tension: 0.1, // Slight curve  
                pointRadius: 5, // Size of point markers  
                pointBackgroundColor: '#FFBD4C', // Point color  
            }  
        ]  
    },  
    options: {  
        responsive: true, // Make chart responsive  
        plugins: {  
            legend: {  
                labels: {  
                    color: '#000', // Legend text color  
                }  
            },  
            title: {  
                display: true,  
                text: 'Social Impact and Insights Into Factory Growth', // Chart title  
                color: '#000', // Title color  
                font: {  
                    size: 24 // Title font size  
                }  
            },  
        },  
        scales: {  
            x: {  
                ticks: {  
                    color: '#000' // X-axis labels color  
                },  
                grid: {  
                    color: '#B0B0B0', // X-axis grid color  
                }  
            },  
            y: {  
                ticks: {  
                    color: '#000' // Y-axis labels color  
                },  
                grid: {  
                    color: '#B0B0B0', // Y-axis grid color  
                },  
                title: {  
                    display: true,  
                    text: 'Employees & Revenue', // Y-axis title  
                    color: '#000', // Title color  
                }  
            }  
        },  
        elements: {  
            line: {  
                borderWidth: 2, // Line thickness  
            },  
            point: {  
                hoverRadius: 7, // Mouse hover radius on points  
            }  
        }  
    }  
});  